#include "board.h"

#define SYSCLK_FREQ	4000000u
#define SYSTICK_FREQ	100u

// todo: tdiv, khist

int main(void)
{
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN | RCC_AHB2ENR_GPIOCEN;

	GPIOA->MODER &= BF2A(LED_BIT, GPIO_MODER_OUT);
	GPIOC->MODER &= BF2A(BTN_BIT, GPIO_MODER_IN);
	GPIOC->PUPDR = BF2(BTN_BIT, GPIO_PUPDR_PU);
	
	SysTick_Config(SYSCLK_FREQ / SYSTICK_FREQ);
//	for (;;)
//		GPIOA->ODR |= 0;
	SCB->SCR = SCB_SCR_SLEEPONEXIT_Msk;	// sleep while not in handler
	__WFI();	// go to sleep
}

void SysTick_Handler(void)
{
	if (++tdiv == SYSTICK_FREQ)
	{
		tdiv = 0;
//		GPIOA->ODR ^= LED_MSK;
		GPIOA->BSRR = LED_MSK << 16 | (~GPIOA->ODR & LED_MSK);
	}
	
//	if ((khist = (khist << 1 | BTN_DOWN) & 3) == 1)
//		GPIOA->ODR ^= LED_MSK;
}
