/*
	KA-NUCLEO-MULTISENSOR LED mpx & ADC demo
	gbm 05'2017
*/

#include "board.h"
#include "disp.h"

int main(void)
{
	RCC->APB1ENR1 |= RCC_APB1ENR1_PWREN | RCC_APB1ENR1_TIM4EN | RCC_APB1ENR1_TIM3EN
		| RCC_APB1ENR1_USART2EN;
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN | RCC_AHB2ENR_GPIOBEN | RCC_AHB2ENR_GPIOCEN;
	// LSE on
	PWR->CR1 |= PWR_CR1_DBP;	// Enable access to BDCR
	RCC->BDCR = RCC_BDCR_LSEON;
	// GPIOB - buttons
	GPIOB->PUPDR = BF2(KEYL_BIT, GPIO_PUPDR_PU) | BF2(KEYR_BIT, GPIO_PUPDR_PU);
	GPIOB->MODER = BF2A(KEYL_BIT, GPIO_MODER_IN) & BF2A(KEYR_BIT, GPIO_MODER_IN);
	// GPIOC - display and button
	GPIOC->MODER = BF2A(0, GPIO_MODER_OUT) & BF2A(1, GPIO_MODER_OUT) & BF2A(2, GPIO_MODER_OUT) & BF2A(3, GPIO_MODER_OUT)
		 & BF2A(4, GPIO_MODER_OUT) & BF2A(5, GPIO_MODER_OUT) & BF2A(6, GPIO_MODER_OUT) & BF2A(7, GPIO_MODER_OUT)
		 & BF2A(8, GPIO_MODER_OUT) & BF2A(9, GPIO_MODER_OUT) & BF2A(10, GPIO_MODER_OUT) & BF2A(11, GPIO_MODER_OUT)
		 & BF2A(13, GPIO_MODER_IN);
	GPIOC->PUPDR = BF2(13, GPIO_PUPDR_PU);	// Nucleo64 button
	// Clock setup
	while (~RCC->BDCR & RCC_BDCR_LSERDY);
	RCC->CR |= RCC_CR_MSIPLLEN;	// Sync MSI to LSE
	// PLL - 80 MHz
	RCC->PLLCFGR = RCC_PLLCFGR_PLLREN | RCC_PLLCFGR_PLLNV(40) | RCC_PLLCFGR_PLLMV(1) | RCC_PLLCFGR_PLLSRC_MSI;
	RCC->CR |= RCC_CR_PLLON;
	// set Flash speed
	FLASH->ACR = FLASH_ACR_DCEN | FLASH_ACR_ICEN | FLASH_ACR_PRFTEN | FLASH_ACR_LATENCY_4WS;	// 4ws 64..80
	while (!(RCC->CR & RCC_CR_PLLRDY));
	RCC->CFGR |= RCC_CFGR_SW_PLL;

	// LED multiplexing timer
	LEDMpx_TIM->PSC = SYSCLK_FREQ / MPX_FREQ / MPX_STEPS - 1;
	LEDMpx_TIM->ARR = MPX_STEPS - 1;
	LEDMpx_TIM->DIER = TIM_DIER_CC1IE | TIM_DIER_UIE;
	LEDMpx_TIM->CR1 = TIM_CR1_CEN;
	
	// interrupts and sleep control
	NVIC_EnableIRQ(LEDMpx_IRQn);
	SCB->SCR = SCB_SCR_SLEEPONEXIT_Msk;	// sleep while not in handler
	__WFI();	// go to sleep
}

// Display stuff
// CPX
// MODER OR masks for 12 LEDs
static const uint32_t cpxmask[] = 
{
	BF2(CPX_LED3_BIT, GPIO_MODER_OUT) | BF2(CPX_LED0_BIT, GPIO_MODER_OUT),	// r on right
	BF2(CPX_LED3_BIT, GPIO_MODER_OUT) | BF2(CPX_LED1_BIT, GPIO_MODER_OUT),	// g on right
	BF2(CPX_LED3_BIT, GPIO_MODER_OUT) | BF2(CPX_LED2_BIT, GPIO_MODER_OUT),	// b on right
	BF2(CPX_LED2_BIT, GPIO_MODER_OUT) | BF2(CPX_LED3_BIT, GPIO_MODER_OUT),
	BF2(CPX_LED2_BIT, GPIO_MODER_OUT) | BF2(CPX_LED0_BIT, GPIO_MODER_OUT),
	BF2(CPX_LED2_BIT, GPIO_MODER_OUT) | BF2(CPX_LED1_BIT, GPIO_MODER_OUT),
	BF2(CPX_LED1_BIT, GPIO_MODER_OUT) | BF2(CPX_LED2_BIT, GPIO_MODER_OUT),
	BF2(CPX_LED1_BIT, GPIO_MODER_OUT) | BF2(CPX_LED3_BIT, GPIO_MODER_OUT),
	BF2(CPX_LED1_BIT, GPIO_MODER_OUT) | BF2(CPX_LED0_BIT, GPIO_MODER_OUT),
	BF2(CPX_LED0_BIT, GPIO_MODER_OUT) | BF2(CPX_LED1_BIT, GPIO_MODER_OUT),	// r on left
	BF2(CPX_LED0_BIT, GPIO_MODER_OUT) | BF2(CPX_LED2_BIT, GPIO_MODER_OUT),	// g on left
	BF2(CPX_LED0_BIT, GPIO_MODER_OUT) | BF2(CPX_LED3_BIT, GPIO_MODER_OUT)	// b on left
};

// m: bgrbgrbgrbgr, msb - left diode, lsb - right diode
static void cpx_encode(uint32_t m)
{
	cpxctrl[0] = 0;
	cpxctrl[1] = 0;
	cpxctrl[2] = 0;
	cpxctrl[3] = 0;
	for (uint8_t i = 0; i < 12; i++)
	{
		if (m & 1)
			cpxctrl[i / 3] |= cpxmask[i];
		m >>= 1;
	}
}

// key handling, brightness control, time increment
void run_every_10ms(void)
{
	static uint8_t k_right_hist, k_left_hist, k_nuc_hist;
	static uint8_t brightness_target = MPX_BRIGHT;
	static _Bool dir;
	
	// key handling
	if ((k_nuc_hist = (k_nuc_hist << 1 | BTN_DOWN) & 3) == 1)
		brightness_target ^= MPX_BRIGHT ^ MPX_DIM;

	if ((k_right_hist = (k_right_hist << 1 | KEYR_DOWN) & 3) == 1)
		dir ^= 1;
	
	if ((k_left_hist = (k_left_hist << 1 | KEYL_DOWN) & 3) == 1)
		brightness_target ^= MPX_BRIGHT ^ MPX_DIM;
	
	// brightness adjust
	uint32_t d = LEDMpx_TIM->CCR1;
	if (d != brightness_target)
		LEDMpx_TIM->CCR1 = d < brightness_target ? d + 1 : d - 1;
	
	static uint8_t tdiv;
	if (++tdiv == 100)
	{
		tdiv = 0;
		// time counter
		static uint8_t phase;
		phase += dir ? NDIGITS - 1 : 1;
		phase %= NDIGITS;
		
		// prepare image
		cpx_encode(042104210 >> (phase * 3));
		
	}
}	
