#include "board.h"

// todo: msg, msgsize, tdiv, msgnum

#define SYSCLK_FREQ	4000000u
#define SYSTICK_FREQ	100u
#define BAUD_RATE	115200u

int main(void)
{
	RCC->AHB1ENR |= RCC_AHB1ENR_DMA1EN;
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN | RCC_AHB2ENR_GPIOBEN | RCC_AHB2ENR_GPIOCEN;
	RCC->APB1ENR1 |= RCC_APB1ENR1_USART2EN;

	GPIOA->AFR[0] |= BF4(2, 7) | BF4(3, 7);	// USART2
	GPIOA->MODER &=
		BF2A(2, GPIO_MODER_AF) & BF2A(3, GPIO_MODER_AF)	// USART2
		& BF2A(LED_BIT, GPIO_MODER_OUT);
	GPIOC->MODER &= BF2A(BTN_BIT, GPIO_MODER_IN);
	GPIOC->PUPDR = BF2(BTN_BIT, GPIO_PUPDR_PU);
	
	DMA1_CSELR->CSELR = BF4(6, USART_DMARq);
	// USART2 setup
	USART2->BRR = (SYSCLK_FREQ + BAUD_RATE / 2) / BAUD_RATE;
	USART2->CR3 = USART_CR3_DMAT;
	USART2->CR1 = USART_CR1_TE | USART_CR1_UE;
	USART2_TX_DMACH->CPAR = (uint32_t)&USART2->TDR;
	
	SysTick_Config(SYSCLK_FREQ / SYSTICK_FREQ);
	SCB->SCR = SCB_SCR_SLEEPONEXIT_Msk;	// sleep while not in handler
	__WFI();	// go to sleep
}

char * msg[] = {
	"one\r\n", "two\r\n", "three\r\n", "four\r\n"
};

uint8_t msgsize[] = {5, 5, 7, 6};

void SysTick_Handler(void)
{
	if (++tdiv == SYSTICK_FREQ)
	{
		tdiv = 0;
		GPIOA->BSRR = LED_MSK << 16 | (~GPIOA->ODR & LED_MSK);
		
		USART2_TX_DMACH->CCR = 0;
		USART2_TX_DMACH->CMAR = (uint32_t)msg[msgnum];
		USART2_TX_DMACH->CNDTR = msgsize[msgnum];
		USART2_TX_DMACH->CCR = DMA_CCR_DIR_M2P | DMA_CCR_MINC | DMA_CCR_EN;
		if (++msgnum == sizeof(msgsize) / sizeof(msgsize[0]))
			msgnum = 0;
	}
}
