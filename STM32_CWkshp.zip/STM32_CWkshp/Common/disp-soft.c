/*
STM32L476 + Nucleo Companion Board
7-segment mpx display, soft refresh, brightness control
gbm, 01'2017
*/

#include "board.h"
#include "disp.h"

uint32_t display[NDIGITS];
uint32_t cpxctrl[NDIGITS];

void LEDMpx_IRQHandler(void)
{
	uint32_t tim_sr = LEDMpx_TIM->SR;
	LEDMpx_TIM->SR = ~(TIM_SR_UIF | TIM_SR_CC1IF);
	
	if (tim_sr & TIM_SR_UIF)
	{
		static uint8_t dig;
		dig = (dig + 1) % NDIGITS;
		LEDMpx_PORT->BSRR = display[dig];	// new digit
		
		// CPX
		CPX_PORT->BSRR = CPX_BSRR_OFF | CPX_LED3_MSK >> dig;
		CPX_PORT->MODER |= cpxctrl[dig];
		
		static uint8_t tdiv;
		if (++tdiv == MPX_FREQ / 100)
		{
			tdiv = 0;
			run_every_10ms();
		}
	}
	if (tim_sr & TIM_SR_CC1IF)
	{
		LEDMpx_PORT->BSRR = DigAct(0) | SegAct(0);	// display off
		CPX_PORT->MODER &= CPX_MODER_OFF;
	}
}
