// 7-segment demo common defs
// Timing
#define SYSCLK_FREQ	80000000u
#define SYSTICK_FREQ	100

#define NDIGITS	4
#define MPX_FREQ	(NDIGITS * 400)
#define MPX_STEPS	100
#define MPX_BRIGHT	(MPX_STEPS - 2)
#define MPX_DIM		(MPX_STEPS / 10)

#if SYSCLK_FREQ % MPX_FREQ
#warning	Imprecise time base!
#endif
extern uint32_t display[NDIGITS];
extern uint32_t display_fade[NDIGITS];
extern uint32_t cpxctrl[NDIGITS];

void common_setup(void);
void run_every_10ms(void);
