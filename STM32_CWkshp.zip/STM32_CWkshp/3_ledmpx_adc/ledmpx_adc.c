/*
	KA-NUCLEO-MULTISENSOR LED mpx & ADC demo
	gbm 05'2017
*/

// todo: digmask, adcavg[], adcval[], adchan[]

#include "board.h"
#include "disp.h"

int main(void)
{
	RCC->APB1ENR1 |= RCC_APB1ENR1_PWREN | RCC_APB1ENR1_TIM4EN | RCC_APB1ENR1_TIM3EN
		| RCC_APB1ENR1_USART2EN;
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN | RCC_AHB2ENR_GPIOBEN | RCC_AHB2ENR_GPIOCEN
		| RCC_AHB2ENR_ADCEN;
	// LSE on
	PWR->CR1 |= PWR_CR1_DBP;	// Enable access to BDCR
	RCC->BDCR = RCC_BDCR_LSEON;
	// GPIOB - buttons
	GPIOB->PUPDR = BF2(KEYL_BIT, GPIO_PUPDR_PU) | BF2(KEYR_BIT, GPIO_PUPDR_PU);
	GPIOB->MODER = BF2A(KEYL_BIT, GPIO_MODER_IN) & BF2A(KEYR_BIT, GPIO_MODER_IN);
	// GPIOC - display and button
	GPIOC->MODER = BF2A(0, GPIO_MODER_OUT) & BF2A(1, GPIO_MODER_OUT) & BF2A(2, GPIO_MODER_OUT) & BF2A(3, GPIO_MODER_OUT)
		 & BF2A(4, GPIO_MODER_OUT) & BF2A(5, GPIO_MODER_OUT) & BF2A(6, GPIO_MODER_OUT) & BF2A(7, GPIO_MODER_OUT)
		 & BF2A(8, GPIO_MODER_OUT) & BF2A(9, GPIO_MODER_OUT) & BF2A(10, GPIO_MODER_OUT) & BF2A(11, GPIO_MODER_OUT)
		 & BF2A(13, GPIO_MODER_IN);
	GPIOC->PUPDR = BF2(13, GPIO_PUPDR_PU);	// Nucleo64 button
	// Clock setup
	while (~RCC->BDCR & RCC_BDCR_LSERDY);
	RCC->CR |= RCC_CR_MSIPLLEN;	// Sync MSI to LSE
	// PLL - 80 MHz
	RCC->PLLCFGR = RCC_PLLCFGR_PLLREN | RCC_PLLCFGR_PLLNV(40) | RCC_PLLCFGR_PLLMV(1) | RCC_PLLCFGR_PLLSRC_MSI;
	RCC->CR |= RCC_CR_PLLON;
	// set Flash speed
	FLASH->ACR = FLASH_ACR_DCEN | FLASH_ACR_ICEN | FLASH_ACR_PRFTEN | FLASH_ACR_LATENCY_4WS;	// 4ws 64..80
	while (!(RCC->CR & RCC_CR_PLLRDY));
	RCC->CFGR |= RCC_CFGR_SW_PLL;

	//ADC
	GPIOA->ASCR = 1 << LDR_BIT;	// ADC connection for LDR
	ADC123_COMMON->CCR = ADC_CCR_TSEN | ADC_CCR_VREFEN | ADC_CCR_CKMODE_1;	// temp sensor, clock prescaler = 2
	ADC1->CR = 0;	// power up
	ADC1->CR = ADC_CR_ADVREGEN;	// power up
	//{&ADC1->CFGR, ADC_CFGR_JQDIS | ADC_CFGR_AUTDLY},	// power up
	ADC1->SMPR1 = BF3(ADCH_VREF, ADC_SMPT_640)
		| BF3(ADCH_LDR, ADC_SMPT_640);
		
	// LED multiplexing timer
	LEDMpx_TIM->PSC = SYSCLK_FREQ / MPX_FREQ / MPX_STEPS - 1;
	LEDMpx_TIM->ARR = MPX_STEPS - 1;
	
#ifdef MPX_DMA
	static const uint32_t displayoff = DigAct(0) | SegAct(0);
	RCC->AHB1ENR |= RCC_AHB1ENR_DMA1EN;
	DMA1_CSELR->CSELR = BF4(0, LEDMpx_DMARq) | BF4(3, LEDMpx_DMARq) | BF4(6, LEDMpx_DMARq);
	LEDMpx_DMACh->CPAR = (uint32_t)&LEDMpx_PORT->BSRR;
	LEDMpx_DMACh->CMAR = (uint32_t)display;
	LEDMpx_DMACh->CNDTR = NDIGITS;
	LEDMpx_DMACh->CCR = DMA_CCR_DIR_M2P | DMA_CCR_MSIZE32 | DMA_CCR_PSIZE32
		| DMA_CCR_MINC | DMA_CCR_CIRC | DMA_CCR_EN;
	LEDMpxOff_DMACh->CPAR = (uint32_t)&LEDMpx_PORT->BSRR;
	LEDMpxOff_DMACh->CMAR = (uint32_t)&displayoff;
	LEDMpxOff_DMACh->CNDTR = 1;
	LEDMpxOff_DMACh->CCR = DMA_CCR_DIR_M2P | DMA_CCR_MSIZE32 | DMA_CCR_PSIZE32
		| DMA_CCR_MINC | DMA_CCR_CIRC | DMA_CCR_EN;
	LEDMpx_TIM->DIER = TIM_DIER_CC1DE | TIM_DIER_UDE;
	SysTick_Config(SYSCLK_FREQ / SYSTICK_FREQ);
#else
	LEDMpx_TIM->DIER = TIM_DIER_CC1IE | TIM_DIER_UIE;
	// interrupts and sleep control
	NVIC_EnableIRQ(LEDMpx_IRQn);
#endif
	LEDMpx_TIM->CR1 = TIM_CR1_CEN;
	SCB->SCR = SCB_SCR_SLEEPONEXIT_Msk;	// sleep while not in handler
	__WFI();	// go to sleep
}

// Display stuff
// encode table for digits 0..9
static const uint8_t encode_digit[] = {
	SEG_A_MSK | SEG_B_MSK | SEG_C_MSK | SEG_D_MSK | SEG_E_MSK | SEG_F_MSK,	// 0
	SEG_B_MSK | SEG_C_MSK,	// 1
	SEG_A_MSK | SEG_B_MSK | SEG_D_MSK | SEG_E_MSK | SEG_G_MSK,	// 2
	SEG_A_MSK | SEG_B_MSK | SEG_C_MSK | SEG_D_MSK | SEG_G_MSK,	// 3
	SEG_B_MSK | SEG_C_MSK | SEG_F_MSK | SEG_G_MSK,	// 4
	SEG_A_MSK | SEG_C_MSK | SEG_D_MSK | SEG_F_MSK | SEG_G_MSK,	// 5
	SEG_A_MSK | SEG_C_MSK | SEG_D_MSK | SEG_E_MSK | SEG_F_MSK | SEG_G_MSK,	// 6
	SEG_A_MSK | SEG_B_MSK | SEG_C_MSK,	// 7
	SEG_A_MSK | SEG_B_MSK | SEG_C_MSK | SEG_D_MSK | SEG_E_MSK | SEG_F_MSK | SEG_G_MSK,	// 8
	SEG_A_MSK | SEG_B_MSK | SEG_C_MSK | SEG_D_MSK | SEG_F_MSK | SEG_G_MSK	// 9
};

// ADC stuff
#define AVGSHIFT	3
enum adch_ {AC_VREF, AC_LDR, AC_NCH};

#define LTSHIFT	6

// channels to convert
uint8_t adchan[] = {ADCH_VREF, ADCH_LDR, ADCH_TSEN};

uint16_t digmask[] = {DIG0_MSK, DIG1_MSK, DIG2_MSK, DIG3_MSK};
uint32_t adcavg[AC_NCH];	// averaging filters
uint16_t adcval[AC_NCH];	// final readouts

static uint16_t cnt = 9999;

// key handling, brightness control, time increment
void run_every_10ms(void)
{
	static uint8_t brightness_target = MPX_BRIGHT;
	static _Bool scan;
	static uint8_t k_right_hist, k_left_hist, k_nuc_hist;
	
	// key handling
	if ((k_nuc_hist = (k_nuc_hist << 1 | BTN_DOWN) & 3) == 1)
		brightness_target ^= MPX_BRIGHT ^ MPX_DIM;

	if ((k_right_hist = (k_right_hist << 1 | KEYR_DOWN) & 3) == 1)
		scan ^= 1;
	
	if ((k_left_hist = (k_left_hist << 1 | KEYL_DOWN) & 3) == 1)
		brightness_target ^= MPX_BRIGHT ^ MPX_DIM;
	
	// brightness adjust
	uint32_t d = LEDMpx_TIM->CCR1;
	if (d != brightness_target)
		LEDMpx_TIM->CCR1 = d < brightness_target ? d + 1 : d - 1;

	{	// ADC stuff
		if (!(ADC1->ISR & (ADC_ISR_EOS | ADC_ISR_ADRDY)))
		{
			static _Bool adcon = 0;
			
			if (!adcon)
			{
				ADC1->CR |= ADC_CR_ADCAL;	// start calibration
				adcon = 1;
			}
			else if (!(ADC1->CR & ADC_CR_ADCAL))
			{
				// turn on
				ADC1->ISR = ADC_ISR_ADRDY;
				ADC1->CR |= ADC_CR_ADEN;
			}
		}
		else if (ADC1->ISR & ADC_ISR_ADRDY)
		{
			// start first conv
			ADC1->SQR1 = adchan[0] << 6;
			ADC1->ISR = ADC_ISR_ADRDY;
			ADC1->CR |= ADC_CR_ADSTART;
		}
		else if (ADC1->ISR & ADC_ISR_EOC)
		{
			static enum adch_ adch;
			// ADC stuff
			adcavg[adch] = adcavg[adch] ? adcavg[adch] - (adcavg[adch] >> AVGSHIFT) + ADC1->DR : ADC1->DR << AVGSHIFT;
			if (adch == AC_VREF)
				adcval[AC_VREF] = VREFINT_CAL * VREFINT_CAL_mV / (adcavg[AC_VREF] >> AVGSHIFT);
			else
			{
				adcval[adch] = adcavg[adch] >> AVGSHIFT;
				if (adch == AC_LDR)
				{
					static uint32_t longterm;
					static _Bool prev, curr;
					longterm = longterm ? longterm - (longterm >> LTSHIFT) + adcval[AC_LDR] : adcval[AC_LDR] << LTSHIFT;
					curr = ((adcval[AC_LDR]) < (longterm >> LTSHIFT) * 14 / 16);
					if (curr && !prev)
					{
						if (++cnt == 10000)
							cnt = 0;
					}
					prev = curr;
				}
			}
			
			ADC1->ISR = ADC_ISR_EOS | ADC_ISR_EOC | ADC_ISR_EOSMP;	// clear flags
			if (++adch == AC_NCH)
				adch = AC_VREF;

			// start next conv
			ADC1->SQR1 = adchan[adch] << 6;
			ADC1->CR |= ADC_CR_ADSTART;
		}
	}
	
	static uint8_t tdiv;
	if (++tdiv == 100)
	{
		tdiv = 0;
		// time counter
		static uint16_t seccnt = 9999;
		if (++seccnt == 10000)
			seccnt = 0;
		
		static enum adch_ disp_channel = AC_VREF;
		if ((seccnt & 1) && scan && ++disp_channel > AC_NCH)
			disp_channel = AC_VREF;
		
		// prepare image
		uint32_t v;
		
		switch (disp_channel)
		{
		case AC_VREF:
			v = adcval[AC_VREF];
			display[0] = DigAct(digmask[0]) | SegAct(encode_digit[v % 10]);
			v /= 10;
			display[1] = DigAct(digmask[1]) | SegAct(encode_digit[v % 10]);
			v /= 10;
			display[2] = DigAct(digmask[2]) | SegAct(encode_digit[v % 10]);
			v /= 10;
			display[3] = DigAct(digmask[3]) | SegAct(encode_digit[v % 10] | SEG_DP_MSK);
			break;
		case AC_LDR:
			v = adcval[AC_LDR];
			display[0] = DigAct(digmask[0]) | SegAct(encode_digit[v % 10] | SEG_DP_MSK);
			v /= 10;
			display[1] = DigAct(digmask[1]) | SegAct(v ? encode_digit[v % 10] : 0);
			v /= 10;
			display[2] = DigAct(digmask[2]) | SegAct(v ? encode_digit[v % 10] : 0);
			v /= 10;
			display[3] = DigAct(digmask[3]) | SegAct(v ? encode_digit[v % 10] : 0);
			break;
		case AC_NCH:
			v = cnt;
			for (uint8_t i = 0; i < NDIGITS; i++)
			{
				display[i] = DigAct(digmask[i]) | SegAct((v || !i ? encode_digit[v % 10] : 0));
				v /= 10;
			}
		}
	}
}

#ifdef MPX_DMA
void SysTick_Handler(void)
{
	run_every_10ms();
}
#endif
